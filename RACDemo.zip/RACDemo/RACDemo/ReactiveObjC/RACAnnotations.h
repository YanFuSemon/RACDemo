//
//  RACAnnotations.h
//  ReactiveObjC
//
//  Created by Eric Horacek on 3/31/17.
//  Copyright © 2017 GitHub. All rights reserved.
//

#ifndef RAC_WARN_UNUSED_RESULT
#define RAC_WARN_UNUSED_RESULT __attribute__((warn_unused_result))
#endif
