//
//  ViewController.m
//  RACDemo
//
//  Created by Fuyan on 2018/2/23.
//  Copyright © 2018年 NYSO. All rights reserved.
//

#import "ViewController.h"
#import "ReactiveObjC.h"
#import "CustomView.h"
#import "NSObject+RACKVOWrapper.h"
@interface ViewController ()
{
    int                     time;
    UIButton             *  sendBtn;
}
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (strong, nonatomic) CustomView *cusView;
@property (strong, nonatomic) RACDisposable *disposable;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

//    //1.创建信号，创建一个数组
//    RACSubject  *subject = [RACSubject subject];
//    //2。订阅信号,函数是编程思想，创建订阅者，将block保存到订阅者对象中，将订阅者保存到数组中
//    [subject subscribeNext:^(id  _Nullable x) {
//        //回调
//    }];
//    //3.发送信号
//    [subject sendNext:@"hello world"];
    
    
    
    //监听文本框输入
    [_textField.rac_textSignal subscribeNext:^(NSString * _Nullable x) {
        NSLog(@"打印输入框内容%@！！！",x);
    }];//一行代码解决。逻辑更加清晰，不需要实现代理协议。

   
    _cusView = [[CustomView alloc] init];
    _cusView.frame =  CGRectMake(100, _textField.frame.origin.y + 50, 140, 150);
    _cusView.backgroundColor = [UIColor yellowColor];
    [self.view addSubview:_cusView];
    //一行搞定代理功能
    [[_cusView rac_signalForSelector:@selector(btnClick:)] subscribeNext:^(RACTuple * _Nullable x) {
        NSLog(@"cusView的按钮被点击了！！！");
    }];
    
    
    UIButton *  btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(10, 360, 60, 30);
    btn.backgroundColor  = [UIColor redColor];
//    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];//原来的套路是这样的
    //监听事件
    [[btn rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        NSLog(@"大兄弟 你点击了！！！");
    }];//一句告别 创建多而复杂的方法和杂乱的逻辑
    [self.view addSubview:btn];
    
    
   //通知
//    [[NSNotificationCenter defaultCenter] addObserver:<#(nonnull id)#> selector:(nonnull SEL) name:<#(nullable NSNotificationName)#> object:<#(nullable id)#>];
    [[[NSNotificationCenter defaultCenter] rac_addObserverForName:@"" object:nil] subscribeNext:^(NSNotification * _Nullable x) {
        
    }];//这酸爽就问还有谁
    
    
    
    
    
    
    sendBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sendBtn.frame = CGRectMake(0, 60, 200, 30);
    sendBtn.backgroundColor  = [UIColor redColor];
    [sendBtn addTarget:self action:@selector(sendMessge:) forControlEvents:UIControlEventTouchUpInside];
    [sendBtn setTitle:@"发送验证码" forState: UIControlStateNormal];
    [self.view addSubview:sendBtn];

}
- (void)timer
{
    //------RACTimer------------
    
    
    
}
- (void)sendMessge:(UIButton *)button
{
    sendBtn.enabled = NO;
    time = 60;
  _disposable =  [[RACSignal interval:1.0 onScheduler:[RACScheduler mainThreadScheduler]] subscribeNext:^(NSDate * _Nullable x) {
       //设置按钮文字
        NSString  *btnTitle = time > 0 ? [NSString stringWithFormat:@"%ds后重新发送",time] : @"发送验证码";
        [sendBtn setTitle:btnTitle forState: time > 0 ? (UIControlStateNormal) : (UIControlStateDisabled)];
      
      if (time > 0 ) {
          sendBtn.enabled = NO;
      }else
      {
          sendBtn.enabled = YES;
          [_disposable dispose];

      }
        
        //减去时间
        time --;
    }];
}
- (void)KVO
{
    //一行搞定 KVO
    [self.cusView rac_observeKeyPath:@"frame" options:NSKeyValueObservingOptionNew observer:self block:^(id value, NSDictionary *change, BOOL causedByDealloc, BOOL affectedOnlyLastComponent) {
        //回调 处理  相当于- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context

    }];
    
    [[self.cusView rac_valuesForKeyPath:@"frame" observer:self] subscribeNext:^(id  _Nullable x) {
        //回调 处理

    }];
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
