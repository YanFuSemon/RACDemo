//
//  CustomView.m
//  RACDemo
//
//  Created by Fuyan on 2018/2/24.
//  Copyright © 2018年 NYSO. All rights reserved.
//

#import "CustomView.h"
#import "ReactiveObjC.h"
@implementation CustomView
@synthesize btn;
- (id)init
{
    self = [super init];
    if (self) {
        btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(20, 20, 100, 100);
        btn.backgroundColor  = [UIColor redColor];
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [btn setTitle:@"点一点" forState: UIControlStateNormal];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:btn];
    }
    return self;
}
//- (RACSubject *)btnClickSingnal
//{
//    if (!_btnClickSingnal) {
//        _btnClickSingnal = [RACSubject subject];
//    }
//    return _btnClickSingnal;
//}
- (void)btnClick:(UIButton *)button
{
//    [self.btnClickSingnal sendNext:@"按钮点击了"];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
