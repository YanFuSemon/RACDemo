//
//  CustomView.h
//  RACDemo
//
//  Created by Fuyan on 2018/2/24.
//  Copyright © 2018年 NYSO. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ReactiveObjC.h"
@interface CustomView : UIView
@property(nonatomic,strong) RACSubject  *btnClickSingnal;
@property(nonatomic,strong) UIButton  *btn;

- (id)init;
@end
